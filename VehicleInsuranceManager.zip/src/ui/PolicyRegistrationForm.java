package ui;
import javax.swing.*;
public class PolicyRegistrationForm extends JFrame {
    public PolicyRegistrationForm() {
        setTitle("Register Policy");
        setSize(400, 300);
        setLayout(null);
        add(new JLabel("(Form UI stub)")); // Expand as needed
        setVisible(true);
    }
}
